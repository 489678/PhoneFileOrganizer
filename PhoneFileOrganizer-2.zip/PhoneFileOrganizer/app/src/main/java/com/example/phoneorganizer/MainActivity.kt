package com.example.phoneorganizer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile
import java.util.Locale


class MainActivity : Activity() {
    private val pickFolderCode = 201
    private var root: DocumentFile? = null
    private var plan: List<FilePlan> = emptyList()
    private lateinit var status: TextView
    private lateinit var preview: TextView
    private lateinit var scanButton: Button
    private lateinit var organizeButton: Button

    data class FilePlan(val file: DocumentFile, val category: String)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }


    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 44, 36, 32)
        }
        val title = TextView(this).apply {
            text = "本地文件整理助手"
            textSize = 25f
            setTextColor(0xff17202a)
        }
        val subtitle = TextView(this).apply {
            text = "只在手机本地扫描。不会上传文件，不会删除文件。"
            textSize = 15f
            setPadding(0, 12, 0, 24)
        }
        val choose = Button(this).apply { text = "① 选择要整理的文件夹"; setOnClickListener { chooseFolder() } }
        scanButton = Button(this).apply { text = "② 扫描并生成整理预览"; isEnabled = false; setOnClickListener { scan() } }
        organizeButton = Button(this).apply { text = "③ 按分类整理文件"; isEnabled = false; setOnClickListener { organize() } }
        status = TextView(this).apply { text = "请先选择一个文件夹。"; textSize = 16f; setPadding(0, 18, 0, 12) }
        preview = TextView(this).apply { textSize = 14f; setTextColor(0xff303841) }
        val scroll = ScrollView(this).apply { addView(preview) }
        outer.addView(title)
        outer.addView(subtitle)
        outer.addView(choose)
        outer.addView(scanButton)
        outer.addView(organizeButton)
        outer.addView(status)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
    }


    private fun chooseFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(intent, pickFolderCode)
    }


    @Deprecated("Legacy SAF picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFolderCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) { }
            root = DocumentFile.fromTreeUri(this, uri)
            status.text = "已选择：${root?.name ?: "文件夹"}。现在可以扫描。"
            scanButton.isEnabled = true
            organizeButton.isEnabled = false
            preview.text = ""
        }
    }


    private fun scan() {
        val selected = root ?: return
        val found = mutableListOf<FilePlan>()
        walk(selected, selected, found)
        plan = found
        val counts = found.groupingBy { it.category }.eachCount().toSortedMap()
        val total = found.size
        status.text = "扫描完成：找到 $total 个文件。"
        preview.text = if (total == 0) "这个文件夹里没有可整理的文件。" else buildString {
            appendLine("整理预览（只处理文件，不移动文件夹）：")
            appendLine()
            counts.forEach { (category, count) -> appendLine("📁 $category  —  $count 个") }
            appendLine()
            appendLine("整理后将创建分类文件夹，并把文件移动到对应位置。")
            appendLine("不会删除文件；如果系统不支持安全移动，文件将保持原位并记录失败。")
            appendLine()
            appendLine("文件清单（最多展示前 200 项）：")
            found.take(200).forEach { appendLine("• ${it.category}/${it.file.name}") }
            if (found.size > 200) appendLine("…另有 ${found.size - 200} 项未在预览中显示")
        }
        organizeButton.isEnabled = total > 0
    }


    private fun walk(base: DocumentFile, current: DocumentFile, out: MutableList<FilePlan>) {
        val children = try { current.listFiles() } catch (_: Exception) { emptyArray() }
        for (item in children) {
            if (item.isDirectory) {
                // Don't recurse into category folders created by a previous run.
                if (item.name in categoryNames) continue
                walk(base, item, out)
            } else if (item.isFile) {
                val cat = categorize(item.name ?: "", item.type ?: "")
                out.add(FilePlan(item, cat))
            }
        }
    }


    private val categoryNames = setOf("文档", "学习资料", "图片", "视频", "音频", "压缩包", "安装包", "其他文件")


    private fun categorize(name: String, mime: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when {
            ext in setOf("apk", "apks", "xapk") -> "安装包"
            ext in setOf("zip", "rar", "7z", "tar", "gz", "bz2") -> "压缩包"
            ext in setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "tif", "tiff") || mime.startsWith("image/") -> "图片"
            ext in setOf("mp4", "mkv", "mov", "avi", "wmv", "flv", "3gp", "webm") || mime.startsWith("video/") -> "视频"
            ext in setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "wma") || mime.startsWith("audio/") -> "音频"
            ext in setOf("pdf", "doc", "docx", "ppt", "pptx", "xls", "xlsx", "txt", "rtf", "csv") -> "文档"
            ext in setOf("c", "cpp", "h", "java", "kt", "py", "js", "ts", "html", "css", "json", "xml", "sql") -> "学习资料"
            else -> "其他文件"
        }
    }


    private fun organize() {
        val base = root ?: return
        var moved = 0
        var failed = 0
        val summary = StringBuilder()
        for (entry in plan) {
            try {
                val folder = base.findFile(entry.category) ?: base.createDirectory(entry.category)
                if (folder == null || !folder.isDirectory) { failed++; continue }
                val source = entry.file
                val sourceParent = source.parentFile
                if (sourceParent == null) { failed++; continue }
                // SAF provider move is used; we deliberately avoid copy-delete fallback.
                DocumentsContract.moveDocument(contentResolver, source.uri, sourceParent.uri, folder.uri)
                moved++
            } catch (e: Exception) {
                failed++
                summary.append("移动失败：${entry.file.name ?: "文件"} (${e.javaClass.simpleName})\n")
            }
        }
        status.text = "整理结束：成功移动 $moved 个，失败 $failed 个。"
        preview.text = "已按类别创建文件夹并整理。\n\n" + if (summary.isEmpty()) "所有移动操作已完成。" else summary.toString()
        organizeButton.isEnabled = false
        Toast.makeText(this, "整理结束：移动 $moved 个文件", Toast.LENGTH_LONG).show()
    }
}
