# 本地文件整理助手 Android 项目


## 项目当前状态
这是 Android 原生 Kotlin 项目源码。当前执行环境没有安装 Android SDK/Gradle，也无法联网下载 Android 构建工具，因此这里无法直接编译并验证 APK。\n

## 自动云端编译 APK（无需在手机安装开发环境）
1. 将此项目上传到 GitHub 仓库（新建一个空仓库即可）。
2. 在仓库页打开 **Actions**。
3. 选择 **Build Android APK** 工作流，点击 **Run workflow**。
4. 工作流完成后进入该次运行页面底部的 **Artifacts**，下载 `PhoneFileOrganizer-debug-apk`。
5. 将 APK 下载到 Android 手机上，点击安装。若 Android 提示，允许浏览器/文件管理器安装未知来源应用。
6. 打开应用，选择你想整理的文件夹，先扫描查看预览，确认后再执行整理。


## 安全说明
- 只扫描用户在系统文件选择器中明确授权的文件夹。
- 不会上传文件。
- 不提供删除操作。
- 整理时仅尝试移动文件；系统文件提供者不支持移动时会显示失败项。
